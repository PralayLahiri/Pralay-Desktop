from django.apps import AppConfig


class EmpAppConfig(AppConfig):
    name = 'emp_app'
