# Ajax-with-Django
Employee Office Examples , with Jquery Ajax


👉 clone project

👉 pip install -r requirements.txt

👉 create super user

👉 add some data

👉 run project

👉 visit localhost:8000

