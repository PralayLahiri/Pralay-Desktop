<!-- Please remove this file from your project -->
<template>
  <div
    class=""
  >
    this is a component which is inserted adadasd in home
  </div>
</template>

<script>
export default {
  name: 'NuxtTutorial',
}
</script>
