<template>
    <div>
        Login page


        <hr />


        
    <p class="p-4 bg-white">
        <nuxt-link to="/">Go Back to homepage</nuxt-link>    
    </p>

    </div>
</template>