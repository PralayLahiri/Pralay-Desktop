VERSION = (0, 0, 3)

default_app_config = 'export_csv.apps.ExportCsvConfig'
