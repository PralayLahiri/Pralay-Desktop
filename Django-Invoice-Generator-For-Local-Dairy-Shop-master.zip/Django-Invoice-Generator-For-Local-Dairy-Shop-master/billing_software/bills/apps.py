from django.apps import AppConfig


class BillsConfig(AppConfig):
    name = 'bills'
