# Django-Invoice-Generator-For-Local-Dairy-Shop
A simple web app made to automate invoice generation created to help a local dairy shop
